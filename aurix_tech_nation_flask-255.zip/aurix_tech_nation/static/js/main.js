(() => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', String(isOpen));
      document.body.classList.toggle('menu-open', isOpen);
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('menu-open');
    }));
  }

  const search = document.querySelector('#course-search');
  const cards = [...document.querySelectorAll('.all-course-card')];
  const empty = document.querySelector('#no-courses');
  if (search && cards.length) {
    search.addEventListener('input', () => {
      const query = search.value.trim().toLowerCase();
      let visible = 0;
      cards.forEach(card => {
        const match = card.dataset.search.includes(query);
        card.hidden = !match;
        if (match) visible += 1;
      });
      if (empty) empty.hidden = visible !== 0;
    });
  }

  const params = new URLSearchParams(window.location.search);
  const course = params.get('course');
  const service = params.get('service');
  const category = document.querySelector('#category');
  const message = document.querySelector('#message');
  if (category && course) category.value = 'Course registration';
  if (message && (course || service)) {
    message.value = course ? `I'm interested in the ${course.replaceAll('-', ' ')} course.` : `I'm interested in: ${service}.`;
  }
})();
